kylinpkg 原始主机收集包

本包包含：
  rootfs/var/lib/dpkg/status       完整 dpkg 状态
  rootfs/etc/apt/...               apt 源、preferences、keyrings
  rootfs/usr/share/keyrings/...    Signed-By 引用的 keyring
  meta/                            系统与版本元数据
  bundle.json、SHA256SUMS

在下载器上导入：
  kylinpkg bundle inspect <本文件.tar.gz>
  kylinpkg bundle import <本文件.tar.gz> --profile <名称> --baseline <名称>
或在图形界面中点击“导入收集包…”。

注意：收集包可能包含 apt 私有源凭据，请妥善保管。
